package com.example.cruddemo1.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cruddemo1.R

class ExcluirUsuarioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_excluir_usuario)
    }
}